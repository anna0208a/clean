const axios = require('axios');

// 確保這是你所用的 API 密鑰
const apiKey = process.env.API_KEY;

async function testAPIKey() {
    try {
        // 用 API 密鑰測試一個簡單的 Google API 請求
        const response = await axios.get(`https://generativelanguage.googleapis.com/v1beta/files/1g4ahp2kub7r?key=${apiKey}`);
        console.log('API Key is valid!', response.data);
    } catch (error) {
        console.error('API Key is invalid or there is an issue with the request:', error.response ? error.response.data : error.message);
    }
}

testAPIKey();
