const axios = require('axios');
require('dotenv').config();

const apiKey = process.env.API_KEY;

if (!apiKey) {
    console.error("API Key is missing.");
    process.exit(1);
}

async function testAPIKey() {
    try {
        const response = await axios.get(`https://generativelanguage.googleapis.com/v1beta/files/1g4ahp2kub7r?key=${apiKey}`);
        console.log('API Key is valid!', response.data);
    } catch (error) {
        console.error('API Key is invalid or there is an issue with the request:', error.response ? error.response.data : error.message);
    }
}

testAPIKey();
